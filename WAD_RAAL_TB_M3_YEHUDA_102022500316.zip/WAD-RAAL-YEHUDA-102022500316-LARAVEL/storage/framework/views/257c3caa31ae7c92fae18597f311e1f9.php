<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Apotek Bang Ganteng - Katalog</title>
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
</head>
<body>
    <div class="container">
        <h2>Katalog Farmasi</h2>
        <p>Master Data Obat, Kategori, Sediaan, dan Pabrikan</p>

        <?php if(session('success')): ?>
            <div style="padding:10px; background:#d1e7dd; color:#0f5132; margin-bottom:15px; border-radius:6px;">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div style="margin-bottom: 20px;">
            <a href="<?php echo e(route('obat.create')); ?>" class="btn">Tambah Obat Baru</a>
        </div>

        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Obat</th>
                    <th>Kategori Obat</th>
                    <th>Sediaan</th>
                    <th>Pabrikan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->nama_obat); ?></td>
                        <td><?php echo e($item->kategori); ?></td>
                        <td><?php echo e($item->sediaan); ?></td>
                        <td><?php echo e($item->pabrikan); ?></td>
                        <td style="display:flex; gap:6px;">
                            <a href="<?php echo e(route('obat.edit', $item->id)); ?>" class="btn btn-warning" style="padding:6px 12px;">Edit</a>

                            <form action="<?php echo e(route('obat.destroy', $item->id)); ?>" method="POST"
                                  onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger" style="padding:6px 12px; border:none; cursor:pointer;">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="6" style="text-align:center;">Belum ada data obat.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\WAD-RAAL-YEHUDA-102022500316-LARAVEL\resources\views/obat/index.blade.php ENDPATH**/ ?>