<?php
    $isEdit = $obat->exists;
    $kategori = ['Analgesik & Antipiretik', 'Antibiotik', 'Vitamin & Suplemen'];
    $sediaan  = ['Tablet', 'Kapsul', 'Sirup', 'Bubuk'];
    $pabrikan = ['Kimia Farma', 'Kalbe Farma', 'Dexa Medica', 'Unknown'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?php echo e($isEdit ? 'Edit Obat' : 'Tambah Obat'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
</head>
<body>
    <div class="container" style="max-width: 600px;">
        <h2><?php echo e($isEdit ? 'Edit Data Obat' : 'Tambah Obat Baru'); ?></h2>
        <p><a href="<?php echo e(route('obat.index')); ?>">&larr; Kembali</a></p>

        <?php if($errors->any()): ?>
            <div style="padding:10px; background:#f8d7da; color:#842029; margin-bottom:15px; border-radius:6px;">
                <ul style="margin-left:18px;">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" class="form-card"
              action="<?php echo e($isEdit ? route('obat.update', $obat->id) : route('obat.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php if($isEdit): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>

            <div class="form-group">
                <label>Nama Obat:</label>
                <input type="text" name="nama_obat" value="<?php echo e(old('nama_obat', $obat->nama_obat)); ?>" required>
            </div>

            <div class="form-group">
                <label>Kategori Obat:</label>
                <select name="kategori" required>
                    <option value="">Pilih Kategori</option>
                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k); ?>" <?php if(old('kategori', $obat->kategori) == $k): echo 'selected'; endif; ?>><?php echo e($k); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label>Sediaan:</label>
                <select name="sediaan" required>
                    <option value="">Pilih Sediaan</option>
                    <?php $__currentLoopData = $sediaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s); ?>" <?php if(old('sediaan', $obat->sediaan) == $s): echo 'selected'; endif; ?>><?php echo e($s); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label>Pabrikan:</label>
                <select name="pabrikan" required>
                    <option value="">Pilih Pabrikan</option>
                    <?php $__currentLoopData = $pabrikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($p); ?>" <?php if(old('pabrikan', $obat->pabrikan) == $p): echo 'selected'; endif; ?>><?php echo e($p); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <button type="submit" class="btn" style="border:none; cursor:pointer; width:100%;">Simpan</button>
        </form>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\WAD-RAAL-YEHUDA-102022500316-LARAVEL\resources\views/obat/form.blade.php ENDPATH**/ ?>